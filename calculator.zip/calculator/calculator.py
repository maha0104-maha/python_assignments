#step1:importing
from tkinter import *

#step2=GUI interaction
window = Tk()
window.title("Calculator")
window.geometry("500x500")

#step3:adding inputs

e=Entry(window,width=56,bd=5)
e.place(x=0,y=0)



#buttons

def click(num):
    result=e.get()
    e.delete(0,END)
    e.insert(0,str(result)+str(num))

def add():
    n1=e.get()
    global math
    math = "Addition"
    global i
    i=int(n1)
    e.delete(0,END)

def subtract():
    n1=e.get()
    global math
    math = "Subtraction"
    global i
    i=int(n1)
    e.delete(0,END)

def multiply():
    n1=e.get()
    global math
    math="multiplication"
    global i
    i=int(n1)
    e.delete(0,END)

def div():
    n1=e.get()
    global math
    math = "Division"
    global i
    i=int(n1)
    e.delete(0,END)

def equal():
    n2=e.get()
    e.delete(0,END)
    if math=='Addition':
        e.insert(0,i+int(n2))
    elif math=='Subtraction':
        e.insert(0,i-int(n2))
    elif math=='multiplication':
        e.insert(0,i*int(n2))
    elif math=='Division':
        e.insert(0,i/int(n2))

def clear():
    e.delete(0,END)
b=Button(window,text="1",width=12,command=lambda :click(1))
b.place(x=10,y=60)

b=Button(window,text="2",width=12,command=lambda :click(2))
b.place(x=80,y=60)

b=Button(window,text="3",width=12,command=lambda :click(3))
b.place(x=170,y=60)

b=Button(window,text="4",width=12,command=lambda :click(4))
b.place(x=10,y=120)

b=Button(window,text="5",width=12,command=lambda :click(5))
b.place(x=80,y=120)

b=Button(window,text="6",width=12,command=lambda :click(6))
b.place(x=170,y=120)

b=Button(window,text="7",width=12,command=lambda :click(7))
b.place(x=10,y=180)

b=Button(window,text="8",width=12,command=lambda :click(8))
b.place(x=80,y=180)

b=Button(window,text="9",width=12,command=lambda :click(9))
b.place(x=170,y=180)


b=Button(window,text="0",width=12,command=lambda :click(0))
b.place(x=10,y=240)

b=Button(window,text="+",width=12,command=add)
b.place(x=80,y=240)

b=Button(window,text="-",width=12,command=subtract)
b.place(x=170,y=240)

b=Button(window,text="*",width=12,command=multiply)
b.place(x=10,y=300)

b=Button(window,text="/",width=12,command=div)
b.place(x=80,y=300)

b=Button(window,text="=",width=12,command=equal)
b.place(x=170,y=300)

b=Button(window,text="clear",width=12,command=clear)
b.place(x=10,y=360)


#step4:stooping

mainloop()